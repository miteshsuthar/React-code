// 2 Answer

import PropTypes from 'prop-types'
import React, { Component } from 'react'

export default class Demo extends Component {

  render() {
    return (
      <div>Demo</div>
    )
  }
}

// this is a class component
